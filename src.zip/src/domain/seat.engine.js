const SeatInventory = require('../models/seatInventory.model');

class SeatEngine {
    /**
     * Safely consumes a seat based on quota rules and spillover logic.
     * MUST be executed within a MongoDB Transaction Session.
     */
    static async consumeSeat(schoolId, sectionId, category, session) {
        // 1. Fetch the exact inventory ledger for this section, locking it for the transaction
        const inventory = await SeatInventory.findOne({ schoolId, sectionId }).session(session);
        
        if (!inventory) {
            throw new Error("Infrastructure Error: Seat inventory not configured for this Section.");
        }

        const requestedQuota = inventory.quotas[category];
        const requestedAvailable = requestedQuota.capacity - (requestedQuota.blockedSeats + requestedQuota.consumedSeats);

        // 2. PRIMARY CHECK: Is there a seat available in their exact category?
        if (requestedAvailable > 0) {
            inventory.quotas[category].consumedSeats += 1;
            await inventory.save({ session });
            return { success: true, consumedCategory: category };
        }

        // 3. SPILLOVER CHECK: If their category is full, are they allowed to take a GENERAL seat?
        if (category !== 'GENERAL' && inventory.allowSpillover) {
            const generalQuota = inventory.quotas['GENERAL'];
            const generalAvailable = generalQuota.capacity - (generalQuota.blockedSeats + generalQuota.consumedSeats);

            if (generalAvailable > 0) {
                inventory.quotas['GENERAL'].consumedSeats += 1;
                await inventory.save({ session });
                return { success: true, consumedCategory: 'GENERAL', spilledOver: true };
            }
        }

        // 4. FAILURE: No seats available
        throw new Error(`Capacity Error: No available seats in the ${category} quota, and no spillover seats available.`);
    }
    
    // Future: static async blockSeat()
    // Future: static async releaseSeat()
}

module.exports = SeatEngine;
