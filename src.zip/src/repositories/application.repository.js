const Application = require('../models/application.model');

class ApplicationRepository {
    static async findById(schoolId, applicationId, session) {
        return await Application.findOne({ _id: applicationId, schoolId }).session(session);
    }

    static async create(applicationData, session) {
        const app = new Application(applicationData);
        return await app.save({ session });
    }

    static async markEnrolled(applicationId, studentId, session) {
        // Direct atomic update - faster than fetching, modifying, and saving
        return await Application.updateOne(
            { _id: applicationId },
            { $set: { status: 'ENROLLED', convertedStudentId: studentId } },
            { session }
        );
    }
}

module.exports = ApplicationRepository;